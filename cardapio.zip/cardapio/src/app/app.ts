import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [FormsModule, RouterOutlet],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {

  busca: string = '';

  categoriaSelecionada: string = 'Todos';

  itensPedido: number = 0;

  pratos = [
    {
      id: 1,
      nome: 'X-Bacon',
      descricao: 'Hambúrguer artesanal, bacon, queijo e molho especial.',
      preco: 28.90,
      categoria: 'Hambúrguer',
      nota: 4.8,
      imagem: 'assets/xbacon.webp',
      disponivel: true
    },

    {
      id: 2,
      nome: 'X-Salada',
      descricao: 'Hambúrguer, queijo, alface, tomate e molho especial.',
      preco: 25.90,
      categoria: 'Hambúrguer',
      nota: 4.6,
      imagem: 'assets/xsalada.webp',
      disponivel: true
    },

    {
      id: 3,
      nome: 'Batata Frita',
      descricao: 'Porção de batata frita crocante.',
      preco: 18.90,
      categoria: 'Porções',
      nota: 4.7,
      imagem: 'assets/batata.webp',
      disponivel: true
    },

    {
      id: 4,
      nome: 'Onion Rings',
      descricao: 'Anéis de cebola empanados e crocantes.',
      preco: 21.90,
      categoria: 'Porções',
      nota: 4.5,
      imagem: 'assets/onion.webp',
      disponivel: true
    },

    {
      id: 5,
      nome: 'Coca-Cola',
      descricao: 'Refrigerante Coca-Cola 350ml.',
      preco: 6.90,
      categoria: 'Bebidas',
      nota: 4.9,
      imagem: 'assets/coca.webp',
      disponivel: true
    },

    {
      id: 6,
      nome: 'Milk-shake',
      descricao: 'Milk-shake cremoso de chocolate.',
      preco: 15.90,
      categoria: 'Bebidas',
      nota: 4.8,
      imagem: 'assets/milk_shake.webp',
      disponivel: false
    }
  ];

  get pratosExibidos() {

    return this.pratos.filter(prato => {

      const correspondeBusca =
        prato.nome.toLowerCase().includes(
          this.busca.toLowerCase()
        );

      const correspondeCategoria =
        this.categoriaSelecionada === 'Todos' ||
        prato.categoria === this.categoriaSelecionada;

      return correspondeBusca && correspondeCategoria;

    });

  }

  selecionarCategoria(categoria: string) {
    this.categoriaSelecionada = categoria;
  }

  adicionarPedido() {
    this.itensPedido++;
  }

}
